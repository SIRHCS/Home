Readme Revisions:
Rev. 001 (02/15/2015) By: Andrew75 (Initial Version) 
Rev. 002 (02/20/2015) By: JollyRoger (Additional info and Edits)
Rev. 003 (02/20/2015) By: Andrew75 (Additional info and Edits)
Rev. 004 (02/20/2015) By: JollyRoger (Minor tweaks)

****************************************************************************************
*******************************> I N F O R M A T I O N <********************************
****************************************************************************************

The goal for this project is to release some playable Sonic X-treme Builds for the world 
to enjoy, based on the original engine.

Please keep in mind that these are not final builds of the game, engine or levels. 

This release in particular is a snapshot in time of the engine and levels the way they
were found in the assets archive, and they were clearly in between a code re-write,
transitioning between major engine revisions.

The original code had to be edited to restore some basic functionality, and to port the

engine to run under modern Windows OS with all the rendering now done using OpenGL.

****************************************************************************************
*******************************> L E V E L - N O T E S <********************************
****************************************************************************************

The playable technical demo includes one level.
Two DEF files (level files) are included in the release, both are the same level.
One is the exact file that was found in the assets archives, the other has been edited
for better playability.
The demo automatically runs the edited level (Level_01.def).

Test.def 
(Original level file, not very playable)

Level_01.def
(Edited level file, Much more Playable than the original.)

To Run the unedited level:  
1: Please back up Level_01.def and Level_01.Pcx, then delete or move the originals.
(In case you'd like to roll back to the more playable edited level versions)
\RSRC\PCX for the .DEF files
\RSRC\DEF for the .pcx map files
2: Change TEST.def and TEST.Pcx names respectively to Level_01.def and Level_01.pcx.
3: Boot game as normal and enjoy!

****************************************************************************************
***********************************> C O N T R O L S <**********************************
****************************************************************************************

Move:
W,A,S,D, or Arrow keys

Jump:
< or Z Keys

World Rotation:
> or X Keys

Restart level:
Tab Key

Quit Game:
Esc Key


****************************************************************************************
*******************************> K N O W N - I S S U E S <******************************
****************************************************************************************

Bear in mind this is a technical demonstration and nowhere near a finished game, so
there are plenty of issues. The following list only contains issues that involve a
partial or incomplete port of the original engine on Windows 7+ and OpenGL.

- Palettes may be wrong: the emulation of texture palettes is incomplete, so some
polygons may have the wrong colors/shading.

- Some polygons are not rendered the same way the Saturn or the NVidia NV1 would do:
affine quadrilateral texture mapping is not implemented yet.

****************************************************************************************
***********************************> C R E D I T S <************************************
****************************************************************************************

The original Sonic X-treme team:
They slaved away many years of their lives working on Sonic X-treme, and without them
none of this would have existed at all.

JollyRoger:
Porting Sonic X-treme Pre-Alpha over to Modern Windows + Open GL.

Andrew75:
Game File data Organization.
DEF file research, editing, and experimentation to help Tweak physics to make the game feel a
little more playabe.

Borman: 
Additional support.

Tichua:
Original Sonic X-treme assets contribution.

Thank you to the community at Assembler forum and the Sonic Retro forum for the support.
